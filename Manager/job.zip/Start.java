import java.io.*;

public class Start{
  public static void main(String[] args) throws IOException{
  new File("myfile.txt").createNewFile();
 }
}
