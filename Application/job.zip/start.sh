javac -cp . Start.java
java -cp . Start
java -version

